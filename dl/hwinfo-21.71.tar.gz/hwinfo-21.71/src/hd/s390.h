/** register all S/390 devices */
void hd_scan_s390(hd_data_t *hd_data);
/** register only S/390 disks */
void hd_scan_s390disks(hd_data_t *hd_data);

