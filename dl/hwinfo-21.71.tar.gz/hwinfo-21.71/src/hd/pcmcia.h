void hd_scan_pcmcia(hd_data_t *hd_data);
