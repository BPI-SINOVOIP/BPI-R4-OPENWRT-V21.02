void hd_scan_sbus (hd_data_t *hd_data);
