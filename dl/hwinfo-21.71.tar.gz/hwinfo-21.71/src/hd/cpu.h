void hd_scan_cpu(hd_data_t *hd_data);
