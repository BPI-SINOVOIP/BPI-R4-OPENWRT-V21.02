void hd_scan_misc(hd_data_t *hd_data);
void hd_scan_misc2(hd_data_t *hd_data);
