void hd_scan_floppy(hd_data_t *hd_data);
