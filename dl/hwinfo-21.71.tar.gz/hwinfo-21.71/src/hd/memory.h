void hd_scan_memory(hd_data_t *hd_data);
