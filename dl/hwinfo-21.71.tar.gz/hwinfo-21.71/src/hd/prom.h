void hd_scan_prom(hd_data_t *hd_data);
