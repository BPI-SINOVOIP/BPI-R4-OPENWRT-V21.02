void hd_scan_int(hd_data_t *hd_data);
