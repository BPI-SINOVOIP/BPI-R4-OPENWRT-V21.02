void hd_scan_manual(hd_data_t *hd_data);
void hd_scan_manual2(hd_data_t *hd_data);
