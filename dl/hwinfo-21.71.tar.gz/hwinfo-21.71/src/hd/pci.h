void hd_scan_sysfs_pci(hd_data_t *hd_data);
