void hd_scan_pppoe(hd_data_t *hd_data);
