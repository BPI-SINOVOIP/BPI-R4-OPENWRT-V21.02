void read_klog(hd_data_t *hd_data);
void dump_klog(hd_data_t *hd_data);
