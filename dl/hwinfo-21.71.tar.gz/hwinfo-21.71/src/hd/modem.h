void hd_scan_modem(hd_data_t *hd_data);
