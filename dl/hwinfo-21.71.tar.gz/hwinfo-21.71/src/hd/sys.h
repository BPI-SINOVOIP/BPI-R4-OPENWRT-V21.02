void hd_scan_sys(hd_data_t *hd_data);
