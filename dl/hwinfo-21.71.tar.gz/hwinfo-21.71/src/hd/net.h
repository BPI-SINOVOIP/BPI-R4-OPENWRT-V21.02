void hd_scan_net(hd_data_t *hd_data);
