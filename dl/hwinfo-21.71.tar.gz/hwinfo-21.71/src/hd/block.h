void hd_scan_sysfs_block(hd_data_t *hd_data);
void hd_scan_sysfs_scsi(hd_data_t *hd_data);
