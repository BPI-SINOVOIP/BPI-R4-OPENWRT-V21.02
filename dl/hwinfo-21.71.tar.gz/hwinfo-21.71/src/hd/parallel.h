void hd_scan_parallel(hd_data_t *hd_data);
