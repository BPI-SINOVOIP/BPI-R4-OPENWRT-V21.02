void hd_scan_fb(hd_data_t *hd_data);
