void hd_scan_serial(hd_data_t *hd_data);
