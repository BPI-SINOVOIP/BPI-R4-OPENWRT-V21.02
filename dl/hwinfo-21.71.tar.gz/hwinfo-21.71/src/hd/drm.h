
#ifndef DRM_H
#define DRM_H

int is_kms_active(hd_data_t *hd_data);

#endif	/* DRM_H */

