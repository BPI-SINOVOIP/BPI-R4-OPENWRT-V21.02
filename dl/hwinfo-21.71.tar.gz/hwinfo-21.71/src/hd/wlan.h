void hd_scan_wlan(hd_data_t *hd_data);
