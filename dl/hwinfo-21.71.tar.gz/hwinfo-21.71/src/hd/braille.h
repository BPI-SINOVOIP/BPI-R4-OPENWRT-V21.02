void hd_scan_braille(hd_data_t *hd_data);
