void hd_scan_kbd(hd_data_t *hd_data);
