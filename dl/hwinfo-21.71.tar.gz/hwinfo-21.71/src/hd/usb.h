void hd_scan_sysfs_usb(hd_data_t *hd_data);
