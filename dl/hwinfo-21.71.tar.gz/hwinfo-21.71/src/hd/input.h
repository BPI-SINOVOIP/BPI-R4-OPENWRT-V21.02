void hd_scan_input(hd_data_t *hd_data);
