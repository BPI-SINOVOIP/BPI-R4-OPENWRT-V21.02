void hd_scan_monitor(hd_data_t *hd_data);
