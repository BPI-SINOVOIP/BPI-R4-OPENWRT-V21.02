void hd_scan_mouse(hd_data_t *hd_data);
