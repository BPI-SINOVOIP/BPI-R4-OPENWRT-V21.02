#include <stdio.h>
#include "hd.h"

#ifndef LIBHD_TINY
#include "hd_ids.h"
#else
#include "hd_ids_tiny.h"
#endif
