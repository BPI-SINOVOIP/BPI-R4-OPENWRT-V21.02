The internal id database is compiled mainly from these public sources:

* pci ids
  http://pci-ids.ucw.cz

* usb ids
  http://www.linux-usb.org/usb.ids

* sdio ids
  https://github.com/systemd/systemd/blob/master/hwdb/sdio.ids
  https://wikidevi.com/wiki/Talk:Linux_Wi-Fi_device_entries

> ### Note:
> Use the 'src/ids/update_pci_usb' script to update pci and usb ids and
> create a pull request of 'hwinfo'.
