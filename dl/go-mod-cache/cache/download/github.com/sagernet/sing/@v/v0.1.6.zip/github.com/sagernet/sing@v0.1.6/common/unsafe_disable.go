//go:build disable_unsafe_buffer

package common

const UnsafeBuffer = false
