package metadata

type Metadata struct {
	Protocol    string
	Source      Socksaddr
	Destination Socksaddr
}
