//go:build !force_stdio

package bufio

const forceSTDIO = false
