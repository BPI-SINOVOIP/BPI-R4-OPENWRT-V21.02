# XTLS

## The latest developement of XTLS has moved to [Xray-core v1.7.0](https://github.com/XTLS/Xray-core/releases/tag/v1.7.0) and https://github.com/XTLS/Xray-core/commit/6f61021f7a7337b2997c442495cb8654d145cf8f

THE FUTURE

## Based on go1.19
