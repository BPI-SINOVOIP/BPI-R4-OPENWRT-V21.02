/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 *  Copyright (C) 2020 Namjae Jeon <linkinjeon@kernel.org>
 */

#ifndef _VERSION_H

#define KSMBD_TOOLS_VERSION "3.4.5"

#endif /* !_VERSION_H */
